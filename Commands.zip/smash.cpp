#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include "Commands.h"
#include "signals.h"

int main(int argc, char* argv[]) {
    std::cout << "starting:" << std::endl;
    std::cout << (1 - 2) << std::endl;
    std::cout << 2 << std::endl;
    std::cout << (1) << std::endl;
    std::cout << (1 - 3) << std::endl;
    std::cout << (1 - 4) << std::endl;
    std::cout << 5 << std::endl;
    std::cout << 6 << std::endl;
    std::cout << 7 << std::endl;
    std::cout << 8 << std::endl;
    std::cout << 9 << std::endl;
    std::cout << 0 << std::endl;
    if(signal(SIGTSTP , ctrlZHandler)==SIG_ERR) {
        perror("smash error: failed to set ctrl-Z handler");
    }
    if(signal(SIGINT , ctrlCHandler)==SIG_ERR) {
        perror("smash error: failed to set ctrl-C handler");
    }

    //TODO: setup sig alarm handler

    SmallShell& smash = SmallShell::getInstance();
    while(true) {
        std::cout << smash.getCurrPrompt();
        std::string cmd_line;
        std::getline(std::cin, cmd_line);
        smash.executeCommand(cmd_line.c_str());
    }
    return 0;
}